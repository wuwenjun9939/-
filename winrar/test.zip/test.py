import os
# 调用os权限
os.system("cls")
os.system("color 2f")
# 使用OS的cmd权限，并用其权限把py文件的背景换成绿色
os.system("title 计算总和打开成功")
# 这个程序的名字叫计算总和
num=input("请输入第一个数字：")
num2=input("请输入第二个数字：")
# input是用来表达你的数字的
num3=num+num2
# 不是这么写的
print("最终结果是：")
print(num3)
print(num+num2)
# 两个不一样的指令，但都是一样的结果
os.system("title 运行成功")
os.system("pause>nul")
# 使用OS的cmd权限，并用其运行pause>nul（暂停并不会弹窗）